function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["dcmotorcontrol.c:39c43"]=1;
    this.traceFlag["dcmotorcontrol.c:48c28"]=1;
    this.traceFlag["dcmotorcontrol.c:49c30"]=1;
    this.traceFlag["dcmotorcontrol.c:67c43"]=1;
    this.traceFlag["dcmotorcontrol.c:76c28"]=1;
    this.traceFlag["dcmotorcontrol.c:77c30"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
